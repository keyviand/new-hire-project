"""Consent-first Windows LAN remote desktop prototype.

Screen frames are JPEG snapshots over HTTP. Input is accepted only after the host
enables control from the localhost-only host panel.
"""

from __future__ import annotations

import argparse
import base64
import ctypes
import hashlib
import hmac
import io
import json
import secrets
import socket
import struct
import threading
import time
from http.cookies import SimpleCookie
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import quote, urlparse

from PIL import ImageGrab
try:
    import qrcode
except ImportError:
    qrcode = None


ROOT = Path(__file__).resolve().parent
AUTH_PATH = ROOT / "auth.json"
SECURE_INPUT_KEY_PATH = ROOT / "secure-input.key"
CONTROL_ENABLED = False
STATE_LOCK = threading.Lock()
FRAME_LOCK = threading.Lock()
LAST_FRAME: tuple[float, bytes, tuple[int, int]] | None = None
SESSIONS: dict[str, float] = {}
LOGIN_ATTEMPTS: dict[str, list[float]] = {}
PENDING_SETUP: dict | None = None
LAST_SECURE_ATTENTION = 0.0
SECURE_ATTENTION_COOLDOWN = 5.0


class InputRejected(Exception):
    def __init__(self, message: str, status: HTTPStatus) -> None:
        super().__init__(message)
        self.status = status


def load_auth() -> dict | None:
    try:
        return json.loads(AUTH_PATH.read_text(encoding="utf-8"))
    except (FileNotFoundError, ValueError):
        return None


AUTH_CONFIG = load_auth()


def save_auth() -> None:
    if AUTH_CONFIG:
        AUTH_PATH.write_text(json.dumps(AUTH_CONFIG, indent=2), encoding="utf-8")


def password_hash(password: str, salt: bytes | None = None) -> tuple[str, str]:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.scrypt(
        password.encode("utf-8"),
        salt=salt,
        n=2**15,
        r=8,
        p=1,
        dklen=32,
        maxmem=64 * 1024 * 1024,
    )
    return base64.b64encode(salt).decode(), base64.b64encode(digest).decode()


def password_valid(password: str, config: dict) -> bool:
    salt = base64.b64decode(config["salt"])
    _, digest = password_hash(password, salt)
    return hmac.compare_digest(digest, config["password_hash"])


def totp(secret: str, at: float | None = None) -> str:
    counter = int((at or time.time()) // 30)
    key = base64.b32decode(secret + "=" * ((8 - len(secret) % 8) % 8))
    digest = hmac.new(key, struct.pack(">Q", counter), hashlib.sha1).digest()
    offset = digest[-1] & 15
    value = (struct.unpack(">I", digest[offset:offset + 4])[0] & 0x7FFFFFFF) % 1_000_000
    return f"{value:06d}"


def totp_valid(secret: str, supplied: str) -> bool:
    supplied = supplied.replace(" ", "")
    return any(
        hmac.compare_digest(totp(secret, time.time() + offset), supplied)
        for offset in (-30, 0, 30)
    )


def recovery_hash(code: str) -> str:
    return hashlib.sha256(code.upper().replace("-", "").encode()).hexdigest()


def relay_secure_input(payload: dict) -> bool:
    """Relay an authenticated secure-input command to the LocalSystem service."""
    if not SECURE_INPUT_KEY_PATH.exists():
        return False
    kind = payload.get("type")
    if kind not in {"key", "text", "secure_attention"}:
        return False
    try:
        key = base64.b64decode(SECURE_INPUT_KEY_PATH.read_text().strip())
        command = {
            "Type": kind,
            "Text": str(payload.get("text", ""))[:128],
            "KeyCode": int(payload.get("keyCode", 0)),
            "Down": bool(payload.get("down")),
        }
        command_bytes = json.dumps(command, separators=(",", ":")).encode()
        encoded_payload = base64.b64encode(command_bytes).decode()
        timestamp = int(time.time())
        nonce = secrets.token_hex(16)
        message = f"{timestamp}\n{nonce}\n{encoded_payload}".encode()
        signature = base64.b64encode(hmac.new(key, message, hashlib.sha256).digest()).decode()
        envelope = {
            "Timestamp": timestamp,
            "Nonce": nonce,
            "Payload": encoded_payload,
            "Signature": signature,
        }
        with socket.create_connection(("127.0.0.1", 8766), timeout=0.25) as relay:
            relay.settimeout(3.0)
            relay.sendall(json.dumps(envelope, separators=(",", ":")).encode() + b"\n")
            with relay.makefile("rb") as response_stream:
                response_line = response_stream.readline(4096)
        response = json.loads(response_line.decode("utf-8"))
        return response.get("ok") is True
    except (OSError, ValueError):
        return False


def secure_desktop_active() -> bool:
    """Return true when this user process cannot open the active input desktop."""
    handle = user32.OpenInputDesktop(0, False, 0x0001)
    if handle:
        user32.CloseDesktop(handle)
        return False
    return True


def local_ip() -> str:
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("8.8.8.8", 80))
        return sock.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        sock.close()


def frame() -> tuple[bytes, tuple[int, int]]:
    global LAST_FRAME
    now = time.monotonic()
    with STATE_LOCK:
        if LAST_FRAME and now - LAST_FRAME[0] < 0.075:
            return LAST_FRAME[1], LAST_FRAME[2]
    with FRAME_LOCK:
        now = time.monotonic()
        with STATE_LOCK:
            if LAST_FRAME and now - LAST_FRAME[0] < 0.075:
                return LAST_FRAME[1], LAST_FRAME[2]
        image = ImageGrab.grab(all_screens=True)
        size = image.size
        image.thumbnail((1440, 900))
        output = io.BytesIO()
        image.convert("RGB").save(
            output,
            "JPEG",
            quality=58,
            optimize=False,
            progressive=False,
            subsampling=2,
        )
        data = output.getvalue()
        with STATE_LOCK:
            LAST_FRAME = (now, data, size)
        return data, size


user32 = ctypes.windll.user32
user32.OpenInputDesktop.restype = ctypes.c_void_p
user32.OpenInputDesktop.argtypes = [ctypes.c_uint, ctypes.c_bool, ctypes.c_uint]
user32.CloseDesktop.argtypes = [ctypes.c_void_p]


def apply_input(payload: dict) -> None:
    global LAST_SECURE_ATTENTION
    kind = payload.get("type")
    if kind == "secure_attention":
        now = time.monotonic()
        with STATE_LOCK:
            if now - LAST_SECURE_ATTENTION < SECURE_ATTENTION_COOLDOWN:
                raise InputRejected(
                    "Wait a few seconds before sending Ctrl+Alt+Delete again.",
                    HTTPStatus.TOO_MANY_REQUESTS,
                )
            LAST_SECURE_ATTENTION = now
        if not relay_secure_input(payload):
            raise InputRejected(
                "The Windows secure-control service did not accept Ctrl+Alt+Delete.",
                HTTPStatus.SERVICE_UNAVAILABLE,
            )
    elif kind == "move":
        width = user32.GetSystemMetrics(78) or user32.GetSystemMetrics(0)
        height = user32.GetSystemMetrics(79) or user32.GetSystemMetrics(1)
        left = user32.GetSystemMetrics(76)
        top = user32.GetSystemMetrics(77)
        x = left + int(float(payload["x"]) * max(width - 1, 1))
        y = top + int(float(payload["y"]) * max(height - 1, 1))
        user32.SetCursorPos(x, y)
    elif kind == "button":
        flags = {("left", True): 0x0002, ("left", False): 0x0004,
                 ("right", True): 0x0008, ("right", False): 0x0010}
        flag = flags.get((payload.get("button"), bool(payload.get("down"))))
        if flag:
            user32.mouse_event(flag, 0, 0, 0, 0)
    elif kind == "wheel":
        user32.mouse_event(0x0800, 0, 0, int(payload.get("delta", 0)), 0)
    elif kind == "key":
        vk = int(payload.get("keyCode", 0))
        if 8 <= vk <= 255:
            user32.keybd_event(vk, 0, 0 if payload.get("down") else 0x0002, 0)
    elif kind == "text":
        for character in str(payload.get("text", ""))[:128]:
            if character in "\r\n":
                user32.keybd_event(0x0D, 0, 0, 0)
                user32.keybd_event(0x0D, 0, 0x0002, 0)
                continue
            scan = user32.VkKeyScanW(ord(character))
            if scan == -1:
                continue
            vk = scan & 0xFF
            modifiers = (scan >> 8) & 0xFF
            modifier_keys = [
                key for bit, key in ((1, 0x10), (2, 0x11), (4, 0x12))
                if modifiers & bit
            ]
            for key in modifier_keys:
                user32.keybd_event(key, 0, 0, 0)
            user32.keybd_event(vk, 0, 0, 0)
            user32.keybd_event(vk, 0, 0x0002, 0)
            for key in reversed(modifier_keys):
                user32.keybd_event(key, 0, 0x0002, 0)
    else:
        raise ValueError("Unsupported input type")
    if kind in {"key", "text"} and secure_desktop_active():
        relay_secure_input(payload)


class Handler(BaseHTTPRequestHandler):
    server_version = "LanRemote/0.1"

    def log_message(self, fmt: str, *args) -> None:
        request_path = urlparse(self.path).path
        if request_path in {"/status", "/input"} or request_path == "/stream":
            return
        print(f"[{self.client_address[0]}] {fmt % args}")

    def send_bytes(self, data: bytes, content_type: str, status=HTTPStatus.OK) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' blob:",
        )
        self.end_headers()
        self.wfile.write(data)

    def json(self, payload: dict, status=HTTPStatus.OK) -> None:
        self.send_bytes(json.dumps(payload).encode(), "application/json", status)

    def localhost(self) -> bool:
        return self.client_address[0] in {"127.0.0.1", "::1"}

    def session_valid(self) -> bool:
        cookie = SimpleCookie(self.headers.get("Cookie", ""))
        token = cookie.get("lan_remote_session")
        if not token:
            return False
        expiry = SESSIONS.get(token.value, 0)
        if expiry <= time.time():
            SESSIONS.pop(token.value, None)
            return False
        return True

    def require_auth(self) -> bool:
        if self.session_valid():
            return True
        self.json({"error": "Authentication required"}, HTTPStatus.UNAUTHORIZED)
        return False

    def body_json(self) -> dict:
        length = min(int(self.headers.get("Content-Length", "0")), 8192)
        return json.loads(self.rfile.read(length) or b"{}")

    def do_GET(self) -> None:
        global PENDING_SETUP
        path = urlparse(self.path).path
        if path == "/":
            self.send_bytes((ROOT / "viewer.html").read_bytes(), "text/html; charset=utf-8")
        elif path == "/app.js":
            self.send_bytes((ROOT / "app.js").read_bytes(), "text/javascript; charset=utf-8")
        elif path == "/style.css":
            self.send_bytes((ROOT / "style.css").read_bytes(), "text/css; charset=utf-8")
        elif path == "/host":
            if not self.localhost():
                self.send_error(HTTPStatus.FORBIDDEN)
                return
            self.send_bytes((ROOT / "host.html").read_bytes(), "text/html; charset=utf-8")
        elif path == "/auth/info":
            self.json({"configured": AUTH_CONFIG is not None, "authenticated": self.session_valid()})
        elif path == "/auth/setup":
            if not self.localhost():
                self.send_error(HTTPStatus.FORBIDDEN)
                return
            if AUTH_CONFIG:
                self.json({"error": "Authentication is already configured"}, HTTPStatus.CONFLICT)
                return
            if not PENDING_SETUP:
                secret = base64.b32encode(secrets.token_bytes(20)).decode().rstrip("=")
                PENDING_SETUP = {"secret": secret, "created": time.time()}
            uri = (
                "otpauth://totp/" + quote("LAN Remote:key") + "?secret="
                + PENDING_SETUP["secret"] + "&issuer=" + quote("LAN Remote")
                + "&digits=6&period=30"
            )
            self.json({"secret": PENDING_SETUP["secret"], "uri": uri, "qr": qrcode is not None})
        elif path == "/auth/qr":
            if not self.localhost() or not PENDING_SETUP or qrcode is None:
                self.send_error(HTTPStatus.NOT_FOUND)
                return
            uri = (
                "otpauth://totp/" + quote("LAN Remote:key") + "?secret="
                + PENDING_SETUP["secret"] + "&issuer=" + quote("LAN Remote")
                + "&digits=6&period=30"
            )
            image = qrcode.make(uri)
            output = io.BytesIO()
            image.save(output, "PNG")
            self.send_bytes(output.getvalue(), "image/png")
        elif path == "/frame":
            if not self.require_auth():
                return
            try:
                data, _ = frame()
                self.send_bytes(data, "image/jpeg")
            except Exception as exc:
                self.json({"error": str(exc)}, HTTPStatus.INTERNAL_SERVER_ERROR)
        elif path == "/stream":
            if not self.require_auth():
                return
            try:
                self.connection.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                self.send_response(HTTPStatus.OK)
                self.send_header("Content-Type", "multipart/x-mixed-replace; boundary=lanremote")
                self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
                self.send_header("Pragma", "no-cache")
                self.send_header("X-Content-Type-Options", "nosniff")
                self.end_headers()
                next_frame = time.monotonic()
                while self.session_valid():
                    data, _ = frame()
                    self.wfile.write(b"--lanremote\r\n")
                    self.wfile.write(b"Content-Type: image/jpeg\r\n")
                    self.wfile.write(f"Content-Length: {len(data)}\r\n\r\n".encode())
                    self.wfile.write(data)
                    self.wfile.write(b"\r\n")
                    self.wfile.flush()
                    next_frame += 1 / 12
                    time.sleep(max(0, next_frame - time.monotonic()))
            except (BrokenPipeError, ConnectionAbortedError, ConnectionResetError):
                pass
            except Exception as exc:
                print(f"Stream error for {self.client_address[0]}: {exc}")
        elif path == "/status":
            if not self.localhost() and not self.require_auth():
                return
            self.json({
                "control": CONTROL_ENABLED,
                "configured": AUTH_CONFIG is not None,
                "unattended": bool(AUTH_CONFIG and AUTH_CONFIG.get("unattended_control")),
                "secure_attention": SECURE_INPUT_KEY_PATH.exists(),
                "stream": "mjpeg",
                "target_fps": 12,
            })
        else:
            self.send_error(HTTPStatus.NOT_FOUND)

    def do_POST(self) -> None:
        global CONTROL_ENABLED, AUTH_CONFIG, PENDING_SETUP
        path = urlparse(self.path).path
        try:
            payload = self.body_json()
        except (ValueError, json.JSONDecodeError):
            self.send_error(HTTPStatus.BAD_REQUEST)
            return
        if path == "/auth/setup":
            if not self.localhost():
                self.send_error(HTTPStatus.FORBIDDEN)
                return
            if AUTH_CONFIG or not PENDING_SETUP:
                self.json({"error": "Setup is unavailable"}, HTTPStatus.CONFLICT)
                return
            password = str(payload.get("password", ""))
            if len(password) < 12:
                self.json({"error": "Password must contain at least 12 characters"}, HTTPStatus.BAD_REQUEST)
                return
            if not totp_valid(PENDING_SETUP["secret"], str(payload.get("otp", ""))):
                self.json({"error": "Authenticator code is incorrect"}, HTTPStatus.BAD_REQUEST)
                return
            salt, digest = password_hash(password)
            recovery_codes = [
                f"{secrets.token_hex(3).upper()}-{secrets.token_hex(3).upper()}"
                for _ in range(8)
            ]
            AUTH_CONFIG = {
                "version": 1, "salt": salt, "password_hash": digest,
                "totp_secret": PENDING_SETUP["secret"],
                "recovery_hashes": [recovery_hash(code) for code in recovery_codes],
                "unattended_control": False,
            }
            save_auth()
            PENDING_SETUP = None
            self.json({"ok": True, "recovery_codes": recovery_codes})
        elif path == "/auth/login":
            if not AUTH_CONFIG:
                self.json({"error": "Authentication has not been configured"}, HTTPStatus.CONFLICT)
                return
            now = time.time()
            ip = self.client_address[0]
            attempts = [t for t in LOGIN_ATTEMPTS.get(ip, []) if now - t < 600]
            LOGIN_ATTEMPTS[ip] = attempts
            if len(attempts) >= 5:
                self.json({"error": "Too many attempts. Try again later."}, HTTPStatus.TOO_MANY_REQUESTS)
                return
            password_ok = password_valid(str(payload.get("password", "")), AUTH_CONFIG)
            code = str(payload.get("otp", ""))
            otp_ok = totp_valid(AUTH_CONFIG["totp_secret"], code)
            recovery = recovery_hash(code)
            recovery_ok = recovery in AUTH_CONFIG.get("recovery_hashes", [])
            if not password_ok or not (otp_ok or recovery_ok):
                attempts.append(now)
                self.json({"error": "Invalid password or authenticator code"}, HTTPStatus.UNAUTHORIZED)
                return
            if recovery_ok:
                AUTH_CONFIG["recovery_hashes"].remove(recovery)
                save_auth()
            LOGIN_ATTEMPTS.pop(ip, None)
            token = secrets.token_urlsafe(32)
            SESSIONS[token] = now + 8 * 60 * 60
            if AUTH_CONFIG.get("unattended_control"):
                with STATE_LOCK:
                    CONTROL_ENABLED = True
                print("Remote control ENABLED by authenticated unattended session")
            data = json.dumps({"ok": True, "expires_in": 28800}).encode()
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Set-Cookie", f"lan_remote_session={token}; Path=/; Max-Age=28800; HttpOnly; Secure; SameSite=Strict")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(data)
        elif path == "/auth/logout":
            cookie = SimpleCookie(self.headers.get("Cookie", ""))
            token = cookie.get("lan_remote_session")
            if token:
                SESSIONS.pop(token.value, None)
            data = b'{"ok":true}'
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Set-Cookie", "lan_remote_session=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Strict")
            self.end_headers()
            self.wfile.write(data)
        elif path == "/host/control":
            if not self.localhost():
                self.send_error(HTTPStatus.FORBIDDEN)
                return
            with STATE_LOCK:
                CONTROL_ENABLED = bool(payload.get("enabled"))
            print("Remote control", "ENABLED" if CONTROL_ENABLED else "DISABLED")
            self.json({"control": CONTROL_ENABLED})
        elif path == "/host/unattended":
            if not self.localhost():
                self.send_error(HTTPStatus.FORBIDDEN)
                return
            if not AUTH_CONFIG:
                self.json({"error": "Authentication is not configured"}, HTTPStatus.CONFLICT)
                return
            AUTH_CONFIG["unattended_control"] = bool(payload.get("enabled"))
            save_auth()
            print(
                "Unattended control",
                "ENABLED" if AUTH_CONFIG["unattended_control"] else "DISABLED",
            )
            self.json({"unattended": AUTH_CONFIG["unattended_control"]})
        elif path == "/input":
            if not self.require_auth():
                return
            if not CONTROL_ENABLED:
                self.json({"error": "Host has not enabled control"}, HTTPStatus.FORBIDDEN)
            else:
                try:
                    apply_input(payload)
                    self.json({"ok": True})
                except InputRejected as exc:
                    self.json({"error": str(exc)}, exc.status)
                except (KeyError, TypeError, ValueError):
                    self.send_error(HTTPStatus.BAD_REQUEST)
        else:
            self.send_error(HTTPStatus.NOT_FOUND)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument(
        "--bind",
        default="127.0.0.1",
        help="Address to listen on (default: localhost for private proxy use)",
    )
    args = parser.parse_args()
    server = ThreadingHTTPServer((args.bind, args.port), Handler)
    print("\nLAN Remote is running")
    print(f"Host panel: http://127.0.0.1:{args.port}/host")
    if args.bind == "127.0.0.1":
        print("Viewer access: private proxy only")
    else:
        print(f"Viewer URL: http://{local_ip()}:{args.port}/")
    print("Authentication:", "configured" if AUTH_CONFIG else "SETUP REQUIRED")
    print("Control starts DISABLED and can only be enabled from the host panel.\n")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
