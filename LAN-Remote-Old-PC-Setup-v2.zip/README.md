# LAN Remote

A Windows-first, consent-based remote desktop prototype for computers on the same trusted local network.

By default the viewer listens on `127.0.0.1:8765`, intended for private access
through Tailscale Serve. The host-administration panel uses a separate
`127.0.0.1:8767` listener that must never be proxied. To deliberately use the
viewer directly on a trusted LAN, start `remote_host.py` with `--bind 0.0.0.0`;
the administration listener remains loopback-only.

## Start

1. Open PowerShell in this folder.
2. Run `powershell -ExecutionPolicy Bypass -File .\start_remote.ps1`.
3. If Windows Firewall asks, allow access on **Private networks only**.
4. On the host, open `http://127.0.0.1:8767/host`.
5. On the other device, open the viewer URL and sign in with the password and
   current authenticator code.
6. Viewing starts after sign-in. Mouse and keyboard work only after
   **Enable remote control** is clicked on the host panel or unattended control
   has been deliberately enabled.

On a phone, tap or drag directly on the remote screen. Use two fingers to
scroll. **Show keyboard** opens a text-entry bar and the phone keyboard;
**Hide keyboard** dismisses the phone keyboard and collapses the bar.

Use the **−**, **+**, and **Fit** controls above the remote screen to adjust
zoom from 100% to 400%. Pinch directly on the screen to zoom around that point.
While zoomed, drag with two fingers to pan around the desktop. At 100%, a
two-finger vertical gesture continues to scroll the remote computer. On a
desktop browser, `Ctrl`+`+`, `Ctrl`+`-`, and `Ctrl`+`0` control local zoom.

**Full screen** expands the viewer to the available display, with a browser
fullscreen request where the device supports it and a fitted app-mode fallback
on devices such as iPhone. **⌨ Keys** opens a compact tray containing Ctrl, Alt,
Shift, Windows, navigation/editing keys, and F1–F12. Modifier buttons stay down
until the next key is sent or **Release modifiers** is pressed. The
Ctrl+Alt+Delete button requires confirmation and is rate-limited.

The **Computer** selector switches between the allowlisted main and old-computer
Tailscale HTTPS addresses. Each computer keeps an independent password, 2FA
enrollment, recovery codes, service key, and authenticated browser session.

## Automatic and unattended access

The native `LanRemoteService` supervisor starts at boot and launches
`auto_start.ps1` in the active interactive session. It replaces the earlier
`LAN Remote Host` logon task. The launcher remains intentionally unprivileged.
The supervisor checks both the authenticated viewer on port 8765 and the local
administration listener on port 8767.

Unattended control is disabled by default. Enable it only from
`http://127.0.0.1:8767/host` on the host computer. The viewer listener on port
8765 rejects host-management routes, including when Tailscale Serve connects to
it from loopback. Once unattended access is enabled, a successful password and
authenticator login enables mouse and keyboard control for that authenticated
session.

## Streaming

The viewer uses one authenticated MJPEG connection targeting 12 frames per
second at a maximum of 1440 by 900 pixels. The older `/frame` snapshot endpoint
remains available as a diagnostic fallback. The persistent stream avoids a new
HTTP request and temporary browser object for every frame.

## Native Windows supervisor

`install_service.ps1` builds and installs the `LanRemoteService` Windows service.
It starts at boot as LocalSystem, waits for an interactive console session, and
launches the unprivileged authenticated agent into that signed-in user's
desktop. The service writes `service-host/service.log` and does not contain
passwords, TOTP secrets, or screen-capture logic. Its protected-input broker
accepts only authenticated local commands from the unprivileged agent.

Windows Session 0 isolation means this supervisor foundation does not yet
capture the pre-login Winlogon desktop. The Step 5B helper relays authenticated
keyboard input to `LogonUI.exe` on the active Winlogon desktop. Messages use a
restricted local key, timestamps, nonces, and HMAC authentication. The helper
refuses all other foreground processes, including `Consent.exe`, so it cannot
approve UAC prompts. The service can issue Windows' protected Ctrl+Alt+Delete
sequence after the signed-in viewer confirms it. Secure-desktop mouse input
remains intentionally unsupported.

Stop the server with Ctrl+C. Restarting generates a new pairing code and resets control to disabled.

## Security boundaries

- Use only on a trusted home/private LAN or through the configured private
  Tailscale network.
- Do not port-forward this service directly to the public internet.
- Password plus authenticator login protects the app session; Tailscale Serve
  supplies the private network route and HTTPS endpoint.
- Proxy only `http://127.0.0.1:8765` with Tailscale Serve. Never expose port
  8767, which is reserved for administration performed on the host computer.
- The host can disable control instantly or stop the process with Ctrl+C.
- Some elevated Windows dialogs cannot be controlled by a non-elevated process.

This is a learning prototype, not production remote-support software.
