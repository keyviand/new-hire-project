import json
import threading
import time
import unittest
import urllib.error
import urllib.request

import remote_host


class RunningServer:
    def __init__(self, *, local_admin):
        self.server = remote_host.create_server(
            ("127.0.0.1", 0), local_admin=local_admin
        )
        self.thread = threading.Thread(
            target=self.server.serve_forever, daemon=True
        )

    @property
    def port(self):
        return self.server.server_address[1]

    def __enter__(self):
        self.thread.start()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.server.shutdown()
        self.thread.join(timeout=5)
        self.server.server_close()


class AdministrationBoundaryTests(unittest.TestCase):
    def setUp(self):
        self.original_auth = remote_host.AUTH_CONFIG
        self.original_pending_setup = remote_host.PENDING_SETUP
        self.original_control = remote_host.CONTROL_ENABLED
        self.original_sessions = remote_host.SESSIONS.copy()
        remote_host.AUTH_CONFIG = None
        remote_host.PENDING_SETUP = None
        remote_host.CONTROL_ENABLED = False
        remote_host.SESSIONS.clear()
        self.opener = urllib.request.build_opener(
            urllib.request.ProxyHandler({})
        )

    def tearDown(self):
        remote_host.AUTH_CONFIG = self.original_auth
        remote_host.PENDING_SETUP = self.original_pending_setup
        remote_host.CONTROL_ENABLED = self.original_control
        remote_host.SESSIONS.clear()
        remote_host.SESSIONS.update(self.original_sessions)

    def request(self, port, path, *, method="GET", payload=None, headers=None):
        data = None
        request_headers = dict(headers or {})
        if payload is not None:
            data = json.dumps(payload).encode()
            request_headers["Content-Type"] = "application/json"
        request = urllib.request.Request(
            f"http://127.0.0.1:{port}{path}",
            data=data,
            headers=request_headers,
            method=method,
        )
        try:
            response = self.opener.open(request, timeout=5)
            return response.status, response.read()
        except urllib.error.HTTPError as exc:
            return exc.code, exc.read()

    def test_public_listener_rejects_host_management(self):
        with RunningServer(local_admin=False) as public:
            self.assertEqual(self.request(public.port, "/host")[0], 403)
            self.assertEqual(self.request(public.port, "/auth/setup")[0], 403)
            self.assertEqual(self.request(public.port, "/status")[0], 401)
            self.assertEqual(
                self.request(
                    public.port,
                    "/host/control",
                    method="POST",
                    payload={"enabled": True},
                )[0],
                403,
            )
            self.assertFalse(remote_host.CONTROL_ENABLED)

    def test_admin_listener_allows_local_management(self):
        with RunningServer(local_admin=True) as admin:
            self.assertEqual(self.request(admin.port, "/host")[0], 200)
            self.assertEqual(self.request(admin.port, "/status")[0], 200)
            self.assertEqual(self.request(admin.port, "/auth/setup")[0], 200)
            self.assertEqual(
                self.request(
                    admin.port,
                    "/host/control",
                    method="POST",
                    payload={"enabled": True},
                )[0],
                200,
            )
            self.assertTrue(remote_host.CONTROL_ENABLED)

    def test_authenticated_viewer_can_read_status(self):
        token = "test-session"
        remote_host.SESSIONS[token] = time.time() + 60
        with RunningServer(local_admin=False) as public:
            status, body = self.request(
                public.port,
                "/status",
                headers={"Cookie": f"lan_remote_session={token}"},
            )
            self.assertEqual(status, 200)
            self.assertIn(b'"configured"', body)


if __name__ == "__main__":
    unittest.main()
