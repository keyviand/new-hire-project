const $ = id => document.getElementById(id);
let connected = false, control = false, lastMove = 0;
let secureAttentionAvailable = false, secureAttentionBusy = false;
async function api(path, options={}) { return fetch(path, options); }

function startStream() {
  if (!connected) return;
  const screen = $('screen');
  screen.onerror = () => {
    if (connected) {
      setTimeout(() => {
        screen.src = '/stream?reconnect=' + Date.now();
      }, 1000);
    }
  };
  screen.onload = () => {
    $('sessionError').textContent = '';
  };
  screen.src = '/stream?start=' + Date.now();
}

async function status() {
  if (!connected) return;
  const r = await api('/status');
  if (r.status === 401) {
    connected = false;
    location.reload();
    return;
  }
  if (r.ok) {
    const data = await r.json();
    control = data.control;
    secureAttentionAvailable = Boolean(data.secure_attention);
    $('state').textContent = control
      ? 'Control enabled'
      : 'View only - waiting for host approval';
    const secureAttentionButton = $('sendCtrlAltDelete');
    if (secureAttentionButton) {
      secureAttentionButton.disabled =
        !control || !secureAttentionAvailable || secureAttentionBusy;
      secureAttentionButton.title = secureAttentionAvailable
        ? 'Send the Windows secure attention sequence'
        : 'The Windows secure-control service is unavailable';
    }
  }
  setTimeout(status, 1000);
}

function send(payload) {
  if (!control) return null;
  return api('/input', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(payload)
  });
}

const computerSwitcher = $('computerSwitcher');
if (computerSwitcher) {
  const allowedComputerUrls = new Set([
    'https://key.tail55939a.ts.net/',
    'https://desktop-ve6q0es.tail55939a.ts.net/'
  ]);
  const currentComputer = Array.from(allowedComputerUrls).find(url =>
    new URL(url).hostname === location.hostname.toLowerCase()
  ) || '';
  computerSwitcher.value = currentComputer;
  computerSwitcher.onchange = () => {
    const destination = computerSwitcher.value;
    if (!allowedComputerUrls.has(destination)) {
      computerSwitcher.value = currentComputer;
      return;
    }
    location.assign(destination);
  };
}

if ($('join')) {
  const screen = $('screen');
  const viewport = $('screenViewport');
  const stage = $('screenStage');
  const zoomOut = $('zoomOut');
  const zoomIn = $('zoomIn');
  const zoomReset = $('zoomReset');
  const zoomLevel = $('zoomLevel');
  const fullscreenToggle = $('fullscreenToggle');
  const MIN_ZOOM = 1;
  const MAX_ZOOM = 4;
  const ZOOM_STEP = .25;
  let zoom = 1;
  let fitWidth = 0;
  let fitHeight = 0;
  let fitMaxHeight = 0;

  function measureFitDimensions() {
    const maxWidth = Math.max(
      1,
      viewport.parentElement.clientWidth ||
        viewport.offsetWidth ||
        window.innerWidth
    );
    const maxHeight = document.body.classList.contains('viewer-fullscreen')
      ? Math.max(160, viewport.clientHeight || window.innerHeight * .72)
      : Math.max(160, window.innerHeight * .72);
    const aspect = screen.naturalWidth > 0 && screen.naturalHeight > 0
      ? screen.naturalWidth / screen.naturalHeight
      : 16 / 9;
    let width = maxWidth;
    let height = width / aspect;
    if (height > maxHeight) {
      height = maxHeight;
      width = height * aspect;
    }
    fitWidth = width;
    fitHeight = height;
    fitMaxHeight = maxHeight;
  }

  function applyScreenSize() {
    if (!fitWidth || !fitHeight) measureFitDimensions();
    stage.style.width = `${fitWidth * zoom}px`;
    stage.style.height = `${fitHeight * zoom}px`;
    viewport.style.height =
      `${Math.min(fitMaxHeight, fitHeight * zoom)}px`;
  }

  function updateZoomControls() {
    const atFit = zoom <= MIN_ZOOM;
    zoomLevel.textContent = `${Math.round(zoom * 100)}%`;
    zoomOut.disabled = atFit;
    zoomReset.disabled = atFit;
    zoomIn.disabled = zoom >= MAX_ZOOM;
  }

  function setZoom(value, focalPoint) {
    const nextZoom = Math.min(
      MAX_ZOOM,
      Math.max(MIN_ZOOM, Math.round(value * 100) / 100)
    );
    const viewportRect = viewport.getBoundingClientRect();
    const focalX = focalPoint?.x ??
      viewportRect.left + viewport.clientWidth / 2;
    const focalY = focalPoint?.y ??
      viewportRect.top + viewport.clientHeight / 2;
    const oldStageRect = stage.getBoundingClientRect();
    const normalizedX = oldStageRect.width
      ? Math.min(1, Math.max(0, (focalX - oldStageRect.left) / oldStageRect.width))
      : .5;
    const normalizedY = oldStageRect.height
      ? Math.min(1, Math.max(0, (focalY - oldStageRect.top) / oldStageRect.height))
      : .5;

    zoom = nextZoom;
    applyScreenSize();

    if (zoom === MIN_ZOOM) {
      viewport.scrollLeft = 0;
      viewport.scrollTop = 0;
      requestAnimationFrame(() => {
        measureFitDimensions();
        applyScreenSize();
      });
    } else {
      const newStageRect = stage.getBoundingClientRect();
      viewport.scrollLeft +=
        newStageRect.left + normalizedX * newStageRect.width - focalX;
      viewport.scrollTop +=
        newStageRect.top + normalizedY * newStageRect.height - focalY;
    }
    updateZoomControls();
  }

  function refreshFit() {
    const rect = viewport.getBoundingClientRect();
    measureFitDimensions();
    setZoom(zoom, {
      x: rect.left + viewport.clientWidth / 2,
      y: rect.top + viewport.clientHeight / 2
    });
  }

  let appFullscreen = false;
  let nativeFullscreenActive = false;

  function fullscreenElement() {
    return document.fullscreenElement || document.webkitFullscreenElement;
  }

  function updateFullscreenMode(active) {
    appFullscreen = active;
    document.body.classList.toggle('viewer-fullscreen', active);
    fullscreenToggle.textContent = active
      ? '⛶ Exit full screen'
      : '⛶ Full screen';
    fullscreenToggle.setAttribute('aria-pressed', String(active));
    requestAnimationFrame(() => requestAnimationFrame(refreshFit));
  }

  async function enterFullscreen() {
    updateFullscreenMode(true);
    const root = document.documentElement;
    const requestFullscreen =
      root.requestFullscreen || root.webkitRequestFullscreen;
    if (!requestFullscreen) return;
    try {
      const result = requestFullscreen.call(root);
      if (result?.then) await result;
      nativeFullscreenActive = Boolean(fullscreenElement());
    } catch {
      // iPhone browsers may not permit page fullscreen. The fitted app mode
      // remains active as a reliable fallback.
      nativeFullscreenActive = false;
    }
  }

  async function exitFullscreen() {
    updateFullscreenMode(false);
    const exit = document.exitFullscreen || document.webkitExitFullscreen;
    if (fullscreenElement() && exit) {
      try {
        const result = exit.call(document);
        if (result?.then) await result;
      } catch {
      }
    }
    nativeFullscreenActive = false;
  }

  fullscreenToggle.onclick = () => {
    if (appFullscreen) exitFullscreen();
    else enterFullscreen();
  };

  function handleFullscreenChange() {
    if (fullscreenElement()) {
      nativeFullscreenActive = true;
      updateFullscreenMode(true);
    } else if (nativeFullscreenActive) {
      nativeFullscreenActive = false;
      updateFullscreenMode(false);
    }
  }

  document.addEventListener('fullscreenchange', handleFullscreenChange);
  document.addEventListener('webkitfullscreenchange', handleFullscreenChange);

  function showSession() {
    connected = true;
    $('connect').hidden = true;
    $('session').hidden = false;
    requestAnimationFrame(refreshFit);
    startStream();
    status();
  }

  async function login() {
    $('connectError').textContent = '';
    const r = await api('/auth/login', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        password: $('password').value,
        otp: $('otp').value.trim()
      })
    });
    const d = await r.json();
    if (!r.ok) {
      $('connectError').textContent = d.error || 'Sign-in failed';
      return;
    }
    showSession();
  }

  $('join').onclick=login;
  $('otp').onkeydown = e => {
    if (e.key === 'Enter') login();
  };
  api('/auth/info').then(r => r.json()).then(d => {
    if (!d.configured) {
      $('connectError').textContent =
        'Finish security setup on the host computer first.';
    } else if (d.authenticated) {
      showSession();
    }
  });
  $('disconnect').onclick = async () => {
    await api('/auth/logout', {method: 'POST'});
    location.reload();
  };

  zoomOut.onclick = () => setZoom(zoom - ZOOM_STEP);
  zoomIn.onclick = () => setZoom(zoom + ZOOM_STEP);
  zoomReset.onclick = () => setZoom(MIN_ZOOM);
  updateZoomControls();
  screen.addEventListener('load', refreshFit);
  window.addEventListener('resize', refreshFit);

  function remoteMove(clientX, clientY, force = false) {
    const now = Date.now();
    if (!force && now - lastMove < 30) return;
    lastMove = now;
    const rect = screen.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    send({
      type: 'move',
      x: Math.max(0, Math.min(1, (clientX - rect.left) / rect.width)),
      y: Math.max(0, Math.min(1, (clientY - rect.top) / rect.height))
    });
  }

  let mousePointerDown = false;
  let mouseButton = 'left';
  const touches = new Map();
  let touchCandidate = null;
  let touchSequenceIsGesture = false;
  let gesture = null;

  function midpoint(points) {
    return {
      x: (points[0].x + points[1].x) / 2,
      y: (points[0].y + points[1].y) / 2
    };
  }

  function distance(points) {
    return Math.hypot(
      points[0].x - points[1].x,
      points[0].y - points[1].y
    );
  }

  function beginGesture() {
    const points = Array.from(touches.values()).slice(0, 2);
    if (points.length < 2) return;
    if (touchCandidate?.buttonDown) {
      send({type: 'button', button: 'left', down: false});
    }
    touchCandidate = null;
    touchSequenceIsGesture = true;
    const center = midpoint(points);
    gesture = {
      mode: zoom > MIN_ZOOM ? 'pan' : 'undecided',
      startDistance: Math.max(1, distance(points)),
      startZoom: zoom,
      startMidpoint: center,
      lastMidpoint: center,
      lastRemoteScrollY: center.y
    };
  }

  function updateGesture() {
    const points = Array.from(touches.values()).slice(0, 2);
    if (points.length < 2) return;
    if (!gesture) beginGesture();
    if (!gesture) return;

    const center = midpoint(points);
    const scale = distance(points) / gesture.startDistance;
    if (Math.abs(scale - 1) > .04) {
      gesture.mode = 'zoom';
    }

    if (gesture.mode === 'zoom') {
      setZoom(gesture.startZoom * scale, center);
    } else if (zoom > MIN_ZOOM || gesture.mode === 'pan') {
      gesture.mode = 'pan';
      viewport.scrollLeft -= center.x - gesture.lastMidpoint.x;
      viewport.scrollTop -= center.y - gesture.lastMidpoint.y;
    } else {
      const deltaY = center.y - gesture.lastRemoteScrollY;
      if (Math.abs(deltaY) >= 8) {
        send({type: 'wheel', delta: deltaY > 0 ? 120 : -120});
        gesture.lastRemoteScrollY = center.y;
      }
    }
    gesture.lastMidpoint = center;
  }

  screen.addEventListener('pointerdown', e => {
    e.preventDefault();
    try {
      screen.setPointerCapture(e.pointerId);
    } catch {
    }

    if (e.pointerType !== 'touch') {
      mousePointerDown = true;
      mouseButton = e.button === 2 ? 'right' : 'left';
      remoteMove(e.clientX, e.clientY, true);
      send({type: 'button', button: mouseButton, down: true});
      return;
    }

    touches.set(e.pointerId, {x: e.clientX, y: e.clientY});
    if (touches.size === 1 && !touchSequenceIsGesture) {
      touchCandidate = {
        pointerId: e.pointerId,
        startX: e.clientX,
        startY: e.clientY,
        lastX: e.clientX,
        lastY: e.clientY,
        buttonDown: false
      };
    } else if (touches.size === 2) {
      beginGesture();
    }
  });

  screen.addEventListener('pointermove', e => {
    if (e.pointerType !== 'touch') {
      remoteMove(e.clientX, e.clientY);
      return;
    }
    if (!touches.has(e.pointerId)) return;

    e.preventDefault();
    touches.set(e.pointerId, {x: e.clientX, y: e.clientY});
    if (touches.size >= 2 || touchSequenceIsGesture) {
      updateGesture();
      return;
    }

    if (!touchCandidate || touchCandidate.pointerId !== e.pointerId) return;
    touchCandidate.lastX = e.clientX;
    touchCandidate.lastY = e.clientY;
    const moved = Math.hypot(
      e.clientX - touchCandidate.startX,
      e.clientY - touchCandidate.startY
    );
    if (!touchCandidate.buttonDown && moved >= 4) {
      remoteMove(touchCandidate.startX, touchCandidate.startY, true);
      send({type: 'button', button: 'left', down: true});
      touchCandidate.buttonDown = true;
    }
    if (touchCandidate.buttonDown) {
      remoteMove(e.clientX, e.clientY);
    }
  }, {passive: false});

  function finishTouch(e, cancelled = false) {
    if (!touches.has(e.pointerId)) return;
    const wasGesture = touchSequenceIsGesture;
    touches.delete(e.pointerId);

    if (wasGesture) {
      if (touches.size < 2) gesture = null;
      if (touches.size === 0) {
        touchSequenceIsGesture = false;
        touchCandidate = null;
      }
      return;
    }

    if (touchCandidate?.pointerId === e.pointerId) {
      if (touchCandidate.buttonDown) {
        remoteMove(e.clientX, e.clientY, true);
        send({type: 'button', button: 'left', down: false});
      } else if (!cancelled) {
        remoteMove(e.clientX, e.clientY, true);
        send({type: 'button', button: 'left', down: true});
        send({type: 'button', button: 'left', down: false});
      }
      touchCandidate = null;
    }
  }

  screen.addEventListener('pointerup', e => {
    e.preventDefault();
    if (e.pointerType === 'touch') {
      finishTouch(e);
    } else if (mousePointerDown) {
      remoteMove(e.clientX, e.clientY, true);
      send({type: 'button', button: mouseButton, down: false});
      mousePointerDown = false;
    }
  });

  screen.addEventListener('pointercancel', e => {
    if (e.pointerType === 'touch') {
      finishTouch(e, true);
    } else if (mousePointerDown) {
      send({type: 'button', button: mouseButton, down: false});
      mousePointerDown = false;
    }
  });

  screen.addEventListener('contextmenu', e => e.preventDefault());
  screen.addEventListener('wheel', e => {
    e.preventDefault();
    if (e.ctrlKey || e.metaKey) {
      setZoom(zoom + (e.deltaY < 0 ? ZOOM_STEP : -ZOOM_STEP), {
        x: e.clientX,
        y: e.clientY
      });
    } else {
      send({type: 'wheel', delta: e.deltaY < 0 ? 120 : -120});
    }
  }, {passive: false});

  window.addEventListener('keydown', e => {
    if (!connected) return;
    if (e.key === 'Escape' && appFullscreen && !fullscreenElement()) {
      e.preventDefault();
      exitFullscreen();
      return;
    }
    const editing = e.target.matches('input,textarea');
    if (!editing && (e.ctrlKey || e.metaKey)) {
      if (e.key === '+' || e.key === '=') {
        e.preventDefault();
        setZoom(zoom + ZOOM_STEP);
        return;
      }
      if (e.key === '-') {
        e.preventDefault();
        setZoom(zoom - ZOOM_STEP);
        return;
      }
      if (e.key === '0') {
        e.preventDefault();
        setZoom(MIN_ZOOM);
        return;
      }
    }
    if (editing || e.target.matches('button') || e.key === 'Escape') return;
    e.preventDefault();
    send({type: 'key', keyCode: e.keyCode, down: true});
  });

  window.addEventListener('keyup', e => {
    if (
      !connected ||
      e.target.matches('input,textarea,button') ||
      e.key === 'Escape'
    ) return;
    if (
      (e.ctrlKey || e.metaKey) &&
      ['+', '=', '-', '0'].includes(e.key)
    ) return;
    e.preventDefault();
    send({type: 'key', keyCode: e.keyCode, down: false});
  });

  const panel = $('keyboardPanel');
  const keyboard = $('mobileKeyboard');
  const specialPanel = $('specialKeyboardPanel');
  const specialToggle = $('specialKeyboardToggle');
  const specialStatus = $('specialKeyboardStatus');
  const secureAttentionButton = $('sendCtrlAltDelete');
  const modifierButtons = Array.from(
    specialPanel.querySelectorAll('[data-modifier-code]')
  );
  const activeModifiers = new Set();
  let specialKeyQueue = Promise.resolve();

  function setSpecialStatus(message, isError = false) {
    specialStatus.textContent = message;
    specialStatus.classList.toggle('error', isError);
  }

  async function requestInput(payload) {
    const request = send(payload);
    if (!request) {
      throw new Error('Host control is not enabled.');
    }
    const response = await request;
    if (response.ok) return;
    let detail = {};
    try {
      detail = await response.json();
    } catch {
    }
    throw new Error(detail.error || `Input failed (${response.status}).`);
  }

  function queueSpecialKey(operation) {
    specialKeyQueue = specialKeyQueue
      .then(operation, operation)
      .catch(error => {
        setSpecialStatus(error.message || 'The key could not be sent.', true);
      });
    return specialKeyQueue;
  }

  function updateModifierButtons() {
    for (const button of modifierButtons) {
      const code = Number(button.dataset.modifierCode);
      button.setAttribute(
        'aria-pressed',
        String(activeModifiers.has(code))
      );
    }
  }

  async function releaseModifiersInternal() {
    const codes = Array.from(activeModifiers).reverse();
    activeModifiers.clear();
    updateModifierButtons();
    for (const code of codes) {
      await requestInput({type: 'key', keyCode: code, down: false});
    }
  }

  function releaseModifiersBestEffort() {
    const codes = Array.from(activeModifiers).reverse();
    activeModifiers.clear();
    updateModifierButtons();
    for (const code of codes) {
      const request = send({type: 'key', keyCode: code, down: false});
      request?.catch(() => {});
    }
  }

  function hideSpecialKeyboard() {
    specialPanel.hidden = true;
    specialToggle.textContent = '⌨ Keys';
    specialToggle.setAttribute('aria-expanded', 'false');
    if (activeModifiers.size) {
      if (control) queueSpecialKey(releaseModifiersInternal);
      else releaseModifiersBestEffort();
    }
    requestAnimationFrame(refreshFit);
  }

  function showSpecialKeyboard() {
    hideKeyboard();
    specialPanel.hidden = false;
    specialToggle.textContent = '⌨ Hide keys';
    specialToggle.setAttribute('aria-expanded', 'true');
    setSpecialStatus(
      control
        ? 'Modifiers stay pressed until the next key or Release.'
        : 'Host control must be enabled before keys can be sent.',
      !control
    );
    requestAnimationFrame(refreshFit);
  }

  function showKeyboard() {
    hideSpecialKeyboard();
    panel.hidden = false;
    $('keyboardToggle').textContent = 'Hide keyboard';
    keyboard.focus();
    requestAnimationFrame(refreshFit);
  }

  function hideKeyboard() {
    keyboard.blur();
    panel.hidden = true;
    $('keyboardToggle').textContent = 'Show keyboard';
    requestAnimationFrame(refreshFit);
  }

  $('keyboardToggle').onclick = () => {
    if (panel.hidden) showKeyboard();
    else hideKeyboard();
  };
  $('hideKeyboard').onclick = hideKeyboard;
  specialToggle.onclick = () => {
    if (specialPanel.hidden) showSpecialKeyboard();
    else hideSpecialKeyboard();
  };
  $('closeSpecialKeyboard').onclick = hideSpecialKeyboard;

  for (const button of modifierButtons) {
    button.onclick = () => queueSpecialKey(async () => {
      const code = Number(button.dataset.modifierCode);
      const willPress = !activeModifiers.has(code);
      await requestInput({type: 'key', keyCode: code, down: willPress});
      if (willPress) activeModifiers.add(code);
      else activeModifiers.delete(code);
      updateModifierButtons();
      setSpecialStatus(
        willPress
          ? `${button.textContent.trim()} is pressed. Choose the next key.`
          : `${button.textContent.trim()} released.`
      );
    });
  }

  for (const button of specialPanel.querySelectorAll('[data-key-code]')) {
    button.onclick = () => queueSpecialKey(async () => {
      const code = Number(button.dataset.keyCode);
      const label = button.getAttribute('aria-label') ||
        button.textContent.trim();
      try {
        await requestInput({type: 'key', keyCode: code, down: true});
        await requestInput({type: 'key', keyCode: code, down: false});
      } finally {
        if (activeModifiers.size) await releaseModifiersInternal();
      }
      setSpecialStatus(`Sent ${label}.`);
    });
  }

  $('releaseModifiers').onclick = () => queueSpecialKey(async () => {
    if (!activeModifiers.size) {
      setSpecialStatus('No modifier keys are pressed.');
      return;
    }
    await releaseModifiersInternal();
    setSpecialStatus('Modifier keys released.');
  });

  secureAttentionButton.onclick = () => {
    if (!control || !secureAttentionAvailable || secureAttentionBusy) {
      setSpecialStatus(
        control
          ? 'The Windows secure-control service is unavailable.'
          : 'Host control is not enabled.',
        true
      );
      return;
    }
    if (!window.confirm(
      'Send Ctrl+Alt+Delete to the host computer? This will open the Windows security screen.'
    )) return;

    secureAttentionBusy = true;
    secureAttentionButton.disabled = true;
    queueSpecialKey(async () => {
      try {
        if (activeModifiers.size) await releaseModifiersInternal();
        setSpecialStatus('Sending Ctrl+Alt+Delete…');
        await requestInput({type: 'secure_attention'});
        setSpecialStatus('Ctrl+Alt+Delete sent to the host computer.');
      } finally {
        secureAttentionBusy = false;
        secureAttentionButton.disabled =
          !control || !secureAttentionAvailable;
      }
    });
  };

  window.addEventListener('pagehide', releaseModifiersBestEffort);
  keyboard.addEventListener('input', e => {
    if (e.data) send({type: 'text', text: e.data});
    keyboard.value = '';
  });
  keyboard.addEventListener('keydown', e => {
    if (e.key === 'Backspace') {
      e.preventDefault();
      send({type: 'key', keyCode: 8, down: true});
      send({type: 'key', keyCode: 8, down: false});
    } else if (e.key === 'Enter') {
      e.preventDefault();
      send({type: 'text', text: '\n'});
    }
  });
}

if($('toggle')){
  let enabled=false,unattended=false;
  async function hostStatus(){const d=await(await fetch('/status')).json();enabled=d.control;unattended=d.unattended;$('controlCard').hidden=!d.configured;$('setupCard').hidden=d.configured;if(d.configured){$('toggle').textContent=enabled?'Disable remote control':'Enable remote control';$('hostState').textContent=enabled?'Remote mouse and keyboard are ENABLED.':'Remote mouse and keyboard are disabled.';$('unattendedToggle').textContent=unattended?'Disable unattended control':'Enable unattended control';$('unattendedState').textContent=unattended?'Unattended control is ENABLED for password + 2FA logins.':'Unattended control is disabled.';}return d;}
  $('toggle').onclick=async()=>{await fetch('/host/control',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({enabled:!enabled})});hostStatus();};
  $('unattendedToggle').onclick=async()=>{await fetch('/host/unattended',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({enabled:!unattended})});hostStatus();};
  hostStatus().then(async d=>{if(d.configured)return;const setup=await(await fetch('/auth/setup')).json();$('secret').textContent=setup.secret;if(setup.qr)$('qr').src='/auth/qr';else $('qr').hidden=true;});
  $('finishSetup').onclick=async()=>{
    $('setupError').textContent='';
    if($('newPassword').value!==$('confirmPassword').value){$('setupError').textContent='Passwords do not match.';return;}
    const r=await fetch('/auth/setup',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:$('newPassword').value,otp:$('setupOtp').value.trim()})});
    const d=await r.json();
    if(!r.ok){$('setupError').textContent=d.error||'Setup failed';return;}
    $('recoveryCodes').hidden=false;$('recoveryCodes').textContent='SAVE THESE ONE-TIME RECOVERY CODES:\n\n'+d.recovery_codes.join('\n')+'\n\nStore them somewhere safe. Each code works once.';
    $('finishSetup').disabled=true;$('setupError').textContent='2FA enabled. Save the recovery codes, then refresh this page.';
  };
}
