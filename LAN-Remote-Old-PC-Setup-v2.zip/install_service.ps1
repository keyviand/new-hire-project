$ErrorActionPreference = 'Stop'
$serviceName = 'LanRemoteService'
$project = Join-Path $PSScriptRoot 'windows-service\LanRemoteService.csproj'
$publish = Join-Path $PSScriptRoot 'service-host'
$executable = Join-Path $publish 'LanRemoteService.exe'
$secureInputKey = Join-Path $PSScriptRoot 'secure-input.key'
$agentScript = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot 'remote_host.py'))
$existing = Get-Service -Name $serviceName -ErrorAction SilentlyContinue

$principal = [Security.Principal.WindowsPrincipal]::new(
    [Security.Principal.WindowsIdentity]::GetCurrent()
)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    $arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    $elevated = Start-Process -FilePath 'powershell.exe' `
        -ArgumentList $arguments -Verb RunAs -WindowStyle Hidden `
        -PassThru
    $elevated.WaitForExit()
    exit $elevated.ExitCode
}

$sasPolicyPath = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'
$sasPolicyName = 'SoftwareSASGeneration'
$sasPolicy = Get-ItemPropertyValue -LiteralPath $sasPolicyPath `
    -Name $sasPolicyName -ErrorAction SilentlyContinue
if ($null -eq $sasPolicy -or [int]$sasPolicy -eq 0) {
    New-ItemProperty -LiteralPath $sasPolicyPath -Name $sasPolicyName `
        -PropertyType DWord -Value 1 -Force | Out-Null
} elseif ([int]$sasPolicy -eq 2) {
    Set-ItemProperty -LiteralPath $sasPolicyPath -Name $sasPolicyName -Value 3
}

if ($existing -and $existing.Status -ne 'Stopped') {
    Stop-Service -Name $serviceName -Force
    $existing.WaitForStatus('Stopped', [TimeSpan]::FromSeconds(15))
}

$agentPattern = [Regex]::Escape($agentScript)
$agentProcesses = Get-CimInstance Win32_Process `
    -Filter "Name = 'python.exe' OR Name = 'pythonw.exe'" |
    Where-Object {
        $_.CommandLine -and $_.CommandLine -match $agentPattern
    }
foreach ($agentProcess in $agentProcesses) {
    Stop-Process -Id $agentProcess.ProcessId -Force -ErrorAction Stop
    Wait-Process -Id $agentProcess.ProcessId -Timeout 10 -ErrorAction SilentlyContinue
}

$portDeadline = [DateTime]::UtcNow.AddSeconds(10)
do {
    $occupiedPorts = Get-NetTCPConnection -LocalPort 8765, 8767 `
        -State Listen -ErrorAction SilentlyContinue
    if (-not $occupiedPorts) {
        break
    }
    Start-Sleep -Milliseconds 250
} while ([DateTime]::UtcNow -lt $portDeadline)
if ($occupiedPorts) {
    throw 'Ports 8765 or 8767 are still occupied after stopping the old LAN Remote agent.'
}

if (-not (Test-Path -LiteralPath $secureInputKey)) {
    $keyBytes = New-Object byte[] 32
    $random = New-Object System.Security.Cryptography.RNGCryptoServiceProvider
    try {
        $random.GetBytes($keyBytes)
    } finally {
        $random.Dispose()
    }
    [System.IO.File]::WriteAllText(
        $secureInputKey,
        [Convert]::ToBase64String($keyBytes),
        [System.Text.UTF8Encoding]::new($false)
    )
}
$currentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
& icacls.exe $secureInputKey /inheritance:r /grant:r `
    'SYSTEM:(F)' 'Administrators:(F)' "${currentUser}:(R)" | Out-Null
if ($LASTEXITCODE -ne 0) {
    throw 'Could not secure the lock-screen input key.'
}

& dotnet publish $project -c Release -r win-x64 --self-contained false `
    -p:PublishSingleFile=true -o $publish
if ($LASTEXITCODE -ne 0) {
    throw 'The native service build failed.'
}

if ($existing) {
    & sc.exe delete $serviceName | Out-Null
    Start-Sleep -Seconds 1
}

& sc.exe create $serviceName binPath= "`"$executable`"" start= auto `
    DisplayName= "LAN Remote Native Supervisor" | Out-Null
if ($LASTEXITCODE -ne 0) {
    throw 'Windows could not create the LAN Remote service.'
}
& sc.exe description $serviceName `
    "Supervisor and protected-input broker for the authenticated LAN Remote agent." | Out-Null
& sc.exe failure $serviceName reset= 86400 actions= restart/5000/restart/15000/none/0 | Out-Null
Start-Service -Name $serviceName

Get-Service -Name $serviceName | Select-Object Name, DisplayName, Status, StartType
