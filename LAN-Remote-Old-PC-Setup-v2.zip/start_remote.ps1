$ErrorActionPreference = 'Stop'
$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) { throw 'Python 3 is required. Install it from python.org, then run this script again.' }
& $python.Source -m pip install -r "$PSScriptRoot\requirements.txt"
& $python.Source "$PSScriptRoot\remote_host.py"
