using System.ComponentModel;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace LanRemoteService;

internal static class Program
{
    private const string ServiceName = "LanRemoteService";
    private const int ServiceWin32OwnProcess = 0x10;
    private const int ServiceStartPending = 0x2;
    private const int ServiceStopPending = 0x3;
    private const int ServiceRunning = 0x4;
    private const int ServiceStopped = 0x1;
    private const int ServiceAcceptStop = 0x1;
    private const int ServiceAcceptShutdown = 0x4;
    private const int ServiceControlStop = 0x1;
    private const int ServiceControlShutdown = 0x5;
    private const uint CreateUnicodeEnvironment = 0x00000400;
    private const uint CreateNoWindow = 0x08000000;
    private const uint TokenAssignPrimary = 0x0001;
    private const uint TokenDuplicate = 0x0002;
    private const uint TokenQuery = 0x0008;
    private const uint TokenAdjustSessionId = 0x0100;
    private const int SecurityImpersonation = 2;
    private const int TokenPrimary = 1;
    private const int TokenSessionId = 12;
    private const uint InputKeyboard = 1;
    private const uint KeyEventKeyUp = 0x0002;
    private const uint KeyEventUnicode = 0x0004;

    private static readonly CancellationTokenSource StopSource = new();
    private static readonly ServiceMainDelegate ServiceMainCallback = ServiceMain;
    private static readonly ServiceHandlerDelegate HandlerCallback = ServiceHandler;
    private static IntPtr _statusHandle;
    private static int _checkpoint;

    public static int Main(string[] args)
    {
        if (args.Length == 2 &&
            args[0].Equals("--secure-input", StringComparison.OrdinalIgnoreCase))
        {
            return RunSecureInputHelper(args[1]);
        }
        if (args.Contains("--console", StringComparer.OrdinalIgnoreCase))
        {
            Log("Running in console diagnostic mode.");
            RunSupervisor(StopSource.Token).GetAwaiter().GetResult();
            return 0;
        }

        ServiceTableEntry[] table =
        [
            new() { Name = ServiceName, Main = ServiceMainCallback },
            new() { Name = null, Main = null }
        ];
        if (!StartServiceCtrlDispatcher(table))
        {
            int error = Marshal.GetLastWin32Error();
            Log($"StartServiceCtrlDispatcher failed: {error}");
            return error;
        }
        return 0;
    }

    private static void ServiceMain(int argumentCount, IntPtr arguments)
    {
        _statusHandle = RegisterServiceCtrlHandlerEx(ServiceName, HandlerCallback, IntPtr.Zero);
        if (_statusHandle == IntPtr.Zero)
        {
            Log($"RegisterServiceCtrlHandlerEx failed: {Marshal.GetLastWin32Error()}");
            return;
        }

        ReportStatus(ServiceStartPending, 0, 10_000);
        Log("Service starting.");
        ReportStatus(ServiceRunning, ServiceAcceptStop | ServiceAcceptShutdown, 0);
        try
        {
            RunSupervisor(StopSource.Token).GetAwaiter().GetResult();
        }
        catch (Exception ex)
        {
            Log($"Supervisor stopped unexpectedly: {ex}");
        }
        finally
        {
            ReportStatus(ServiceStopped, 0, 0);
            Log("Service stopped.");
        }
    }

    private static int ServiceHandler(int control, int eventType, IntPtr eventData, IntPtr context)
    {
        if (control is ServiceControlStop or ServiceControlShutdown)
        {
            ReportStatus(ServiceStopPending, 0, 10_000);
            StopSource.Cancel();
        }
        return 0;
    }

    private static async Task RunSupervisor(CancellationToken cancellationToken)
    {
        await Task.WhenAll(
            SuperviseInteractiveAgent(cancellationToken),
            RunSecureInputRelay(cancellationToken));
    }

    private static async Task SuperviseInteractiveAgent(CancellationToken cancellationToken)
    {
        DateTime lastLaunch = DateTime.MinValue;
        while (!cancellationToken.IsCancellationRequested)
        {
            try
            {
                bool viewerOpen = await PortOpen(8765, cancellationToken);
                bool adminOpen = await PortOpen(8767, cancellationToken);
                if ((!viewerOpen || !adminOpen) &&
                    DateTime.UtcNow - lastLaunch > TimeSpan.FromSeconds(20))
                {
                    uint sessionId = WTSGetActiveConsoleSessionId();
                    if (sessionId != uint.MaxValue)
                    {
                        lastLaunch = DateTime.UtcNow;
                        LaunchAgent(sessionId);
                    }
                }
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                break;
            }
            catch (Exception ex)
            {
                Log($"Supervisor check failed: {ex.Message}");
            }

            try
            {
                await Task.Delay(TimeSpan.FromSeconds(5), cancellationToken);
            }
            catch (OperationCanceledException)
            {
                break;
            }
        }
    }

    private static async Task RunSecureInputRelay(CancellationToken cancellationToken)
    {
        string keyPath = Path.Combine(
            Directory.GetParent(AppContext.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar))!.FullName,
            "secure-input.key");
        if (!File.Exists(keyPath))
        {
            Log("Secure-input relay disabled: key file is missing.");
            return;
        }

        byte[] key;
        try
        {
            key = Convert.FromBase64String(File.ReadAllText(keyPath).Trim());
        }
        catch (Exception ex)
        {
            Log($"Secure-input relay disabled: invalid key file ({ex.Message}).");
            return;
        }

        HashSet<string> recentNonces = [];
        TcpListener listener = new(IPAddress.Loopback, 8766);
        listener.Start(4);
        Log("Secure-input relay listening on 127.0.0.1:8766.");
        try
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                TcpClient client = await listener.AcceptTcpClientAsync(cancellationToken);
                await HandleSecureInputClient(client, key, recentNonces);
            }
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
        }
        finally
        {
            listener.Stop();
            CryptographicOperations.ZeroMemory(key);
        }
    }

    private static async Task HandleSecureInputClient(
        TcpClient client, byte[] key, HashSet<string> recentNonces)
    {
        using (client)
        {
            client.ReceiveTimeout = 3000;
            client.SendTimeout = 3000;
            try
            {
                using NetworkStream stream = client.GetStream();
                using StreamReader reader = new(stream, Encoding.UTF8, false, 4096, leaveOpen: true);
                using StreamWriter writer = new(stream, new UTF8Encoding(false), 4096, leaveOpen: true)
                    { AutoFlush = true };
                string? line = await reader.ReadLineAsync();
                RelayEnvelope? envelope = JsonSerializer.Deserialize<RelayEnvelope>(line ?? "");
                if (envelope is null || !ValidateEnvelope(envelope, key, recentNonces))
                {
                    await writer.WriteLineAsync("{\"ok\":false}");
                    return;
                }

                byte[] payload = Convert.FromBase64String(envelope.Payload);
                InputCommand? command = JsonSerializer.Deserialize<InputCommand>(payload);
                if (command is null ||
                    command.Type is not ("key" or "text" or "secure_attention"))
                {
                    await writer.WriteLineAsync("{\"ok\":false}");
                    return;
                }

                if (command.Type == "secure_attention")
                {
                    try
                    {
                        SendSAS(false);
                        Log("Authenticated Ctrl+Alt+Delete request sent.");
                        await writer.WriteLineAsync("{\"ok\":true}");
                    }
                    catch (Exception ex)
                    {
                        Log($"Ctrl+Alt+Delete request failed: {ex.Message}");
                        await writer.WriteLineAsync("{\"ok\":false}");
                    }
                    return;
                }

                bool launched = LaunchSecureHelper(
                    WTSGetActiveConsoleSessionId(), envelope.Payload);
                await writer.WriteLineAsync(launched ? "{\"ok\":true}" : "{\"ok\":false}");
            }
            catch (Exception ex)
            {
                Log($"Secure-input relay request failed: {ex.Message}");
            }
        }
    }

    private static bool ValidateEnvelope(
        RelayEnvelope envelope, byte[] key, HashSet<string> recentNonces)
    {
        long now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        if (Math.Abs(now - envelope.Timestamp) > 10 ||
            envelope.Nonce.Length is < 16 or > 128 ||
            envelope.Payload.Length > 2048)
        {
            return false;
        }
        lock (recentNonces)
        {
            if (!recentNonces.Add(envelope.Nonce))
            {
                return false;
            }
            if (recentNonces.Count > 1024)
            {
                recentNonces.Clear();
                recentNonces.Add(envelope.Nonce);
            }
        }
        byte[] message = Encoding.UTF8.GetBytes(
            $"{envelope.Timestamp}\n{envelope.Nonce}\n{envelope.Payload}");
        byte[] expected = HMACSHA256.HashData(key, message);
        byte[] supplied;
        try
        {
            supplied = Convert.FromBase64String(envelope.Signature);
        }
        catch (FormatException)
        {
            return false;
        }
        return CryptographicOperations.FixedTimeEquals(expected, supplied);
    }

    private static bool LaunchSecureHelper(uint sessionId, string payload)
    {
        if (sessionId == uint.MaxValue)
        {
            return false;
        }
        if (!OpenProcessToken(
                GetCurrentProcess(),
                TokenAssignPrimary | TokenDuplicate | TokenQuery | TokenAdjustSessionId,
                out IntPtr processToken))
        {
            Log($"OpenProcessToken failed: {Marshal.GetLastWin32Error()}");
            return false;
        }

        IntPtr primaryToken = IntPtr.Zero;
        IntPtr sessionPointer = IntPtr.Zero;
        try
        {
            if (!DuplicateTokenEx(
                    processToken,
                    TokenAssignPrimary | TokenDuplicate | TokenQuery | TokenAdjustSessionId,
                    IntPtr.Zero,
                    SecurityImpersonation,
                    TokenPrimary,
                    out primaryToken))
            {
                Log($"DuplicateTokenEx failed: {Marshal.GetLastWin32Error()}");
                return false;
            }
            sessionPointer = Marshal.AllocHGlobal(sizeof(uint));
            Marshal.WriteInt32(sessionPointer, unchecked((int)sessionId));
            if (!SetTokenInformation(primaryToken, TokenSessionId, sessionPointer, sizeof(uint)))
            {
                Log($"SetTokenInformation(TokenSessionId) failed: {Marshal.GetLastWin32Error()}");
                return false;
            }

            string executable = Environment.ProcessPath
                ?? Path.Combine(AppContext.BaseDirectory, "LanRemoteService.exe");
            string command = $"\"{executable}\" --secure-input {payload}";
            StartupInfo startup = new()
            {
                Size = Marshal.SizeOf<StartupInfo>(),
                Desktop = @"winsta0\Winlogon",
                ShowWindow = 0
            };
            if (!CreateProcessAsUser(
                    primaryToken, executable, new StringBuilder(command),
                    IntPtr.Zero, IntPtr.Zero, false, CreateNoWindow,
                    IntPtr.Zero, AppContext.BaseDirectory, ref startup,
                    out ProcessInformation process))
            {
                Log($"Secure helper CreateProcessAsUser failed: {Marshal.GetLastWin32Error()}");
                return false;
            }
            CloseHandle(process.Thread);
            WaitForSingleObject(process.Process, 2000);
            CloseHandle(process.Process);
            return true;
        }
        finally
        {
            if (sessionPointer != IntPtr.Zero) Marshal.FreeHGlobal(sessionPointer);
            if (primaryToken != IntPtr.Zero) CloseHandle(primaryToken);
            CloseHandle(processToken);
        }
    }

    private static int RunSecureInputHelper(string payload)
    {
        try
        {
            IntPtr foreground = GetForegroundWindow();
            if (foreground == IntPtr.Zero)
            {
                return 20;
            }
            GetWindowThreadProcessId(foreground, out uint processId);
            using Process foregroundProcess = Process.GetProcessById(unchecked((int)processId));
            bool isLogonUi = foregroundProcess.ProcessName.Equals(
                "LogonUI", StringComparison.OrdinalIgnoreCase);
            bool isLockApp = foregroundProcess.ProcessName.Equals(
                "LockApp", StringComparison.OrdinalIgnoreCase);
            if (!isLogonUi && !isLockApp)
            {
                Log($"Secure helper refused foreground process {foregroundProcess.ProcessName}.");
                return 21;
            }

            byte[] data = Convert.FromBase64String(payload);
            InputCommand? command = JsonSerializer.Deserialize<InputCommand>(data);
            if (command is null)
            {
                return 22;
            }
            if (isLockApp && !IsLockScreenAdvanceCommand(command))
            {
                Log("Secure helper refused non-advance input on LockApp.");
                return 25;
            }
            if (command.Type == "text")
            {
                foreach (char character in (command.Text ?? "")[..Math.Min(command.Text?.Length ?? 0, 128)])
                {
                    SendCharacter(character);
                }
                return 0;
            }
            if (command.Type == "key" && command.KeyCode is >= 8 and <= 255)
            {
                SendVirtualKey((ushort)command.KeyCode, command.Down);
                return 0;
            }
            return 23;
        }
        catch (Exception ex)
        {
            Log($"Secure helper failed: {ex.Message}");
            return 24;
        }
    }

    private static bool IsLockScreenAdvanceCommand(InputCommand command) =>
        (command.Type == "key" && command.KeyCode is 13 or 32) ||
        (command.Type == "text" && command.Text is "\r" or "\n" or "\r\n" or " ");

    private static void SendCharacter(char character)
    {
        if (character is '\r' or '\n')
        {
            SendVirtualKey(0x0D, true);
            SendVirtualKey(0x0D, false);
            return;
        }
        SendKeyboardInput(0, character, KeyEventUnicode);
        SendKeyboardInput(0, character, KeyEventUnicode | KeyEventKeyUp);
    }

    private static void SendVirtualKey(ushort virtualKey, bool down) =>
        SendKeyboardInput(virtualKey, 0, down ? 0 : KeyEventKeyUp);

    private static void SendKeyboardInput(ushort virtualKey, ushort scanCode, uint flags)
    {
        NativeInput[] input =
        [
            new()
            {
                Type = InputKeyboard,
                Union = new InputUnion
                {
                    Keyboard = new KeyboardInput
                    {
                        VirtualKey = virtualKey,
                        ScanCode = scanCode,
                        Flags = flags
                    }
                }
            }
        ];
        SendInput(1, input, Marshal.SizeOf<NativeInput>());
    }

    private static async Task<bool> PortOpen(
        int port, CancellationToken cancellationToken)
    {
        using TcpClient client = new();
        try
        {
            using CancellationTokenSource timeout =
                CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            timeout.CancelAfter(TimeSpan.FromSeconds(2));
            await client.ConnectAsync("127.0.0.1", port, timeout.Token);
            return true;
        }
        catch
        {
            return false;
        }
    }

    private static void LaunchAgent(uint sessionId)
    {
        string serviceDirectory = AppContext.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar);
        string appDirectory = Directory.GetParent(serviceDirectory)?.FullName
            ?? throw new InvalidOperationException("Cannot locate LAN Remote directory.");
        string script = Path.Combine(appDirectory, "auto_start.ps1");
        if (!File.Exists(script))
        {
            Log($"Agent launcher is missing: {script}");
            return;
        }

        if (!WTSQueryUserToken(sessionId, out IntPtr userToken))
        {
            Log($"WTSQueryUserToken({sessionId}) failed: {Marshal.GetLastWin32Error()}");
            return;
        }

        IntPtr environment = IntPtr.Zero;
        try
        {
            if (!CreateEnvironmentBlock(out environment, userToken, false))
            {
                Log($"CreateEnvironmentBlock failed: {Marshal.GetLastWin32Error()}");
                return;
            }

            string command =
                $"powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File \"{script}\"";
            StartupInfo startup = new()
            {
                Size = Marshal.SizeOf<StartupInfo>(),
                Desktop = @"winsta0\default",
                ShowWindow = 0
            };
            if (!CreateProcessAsUser(
                    userToken,
                    null,
                    new StringBuilder(command),
                    IntPtr.Zero,
                    IntPtr.Zero,
                    false,
                    CreateUnicodeEnvironment | CreateNoWindow,
                    environment,
                    appDirectory,
                    ref startup,
                    out ProcessInformation process))
            {
                Log($"CreateProcessAsUser failed: {new Win32Exception(Marshal.GetLastWin32Error()).Message}");
                return;
            }

            try
            {
                Log($"Started interactive agent PID {process.ProcessId} in session {sessionId}.");
            }
            finally
            {
                CloseHandle(process.Thread);
                CloseHandle(process.Process);
            }
        }
        finally
        {
            if (environment != IntPtr.Zero)
            {
                DestroyEnvironmentBlock(environment);
            }
            CloseHandle(userToken);
        }
    }

    private static void ReportStatus(int state, int acceptedControls, int waitHint)
    {
        ServiceStatus status = new()
        {
            ServiceType = ServiceWin32OwnProcess,
            CurrentState = state,
            ControlsAccepted = acceptedControls,
            Win32ExitCode = 0,
            ServiceSpecificExitCode = 0,
            CheckPoint = state is ServiceRunning or ServiceStopped ? 0 : ++_checkpoint,
            WaitHint = waitHint
        };
        SetServiceStatus(_statusHandle, ref status);
    }

    private static void Log(string message)
    {
        try
        {
            string path = Path.Combine(AppContext.BaseDirectory, "service.log");
            File.AppendAllText(path, $"{DateTimeOffset.Now:O} {message}{Environment.NewLine}");
        }
        catch
        {
            // Logging must never terminate the service.
        }
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct ServiceTableEntry
    {
        [MarshalAs(UnmanagedType.LPWStr)] public string? Name;
        public ServiceMainDelegate? Main;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct ServiceStatus
    {
        public int ServiceType;
        public int CurrentState;
        public int ControlsAccepted;
        public int Win32ExitCode;
        public int ServiceSpecificExitCode;
        public int CheckPoint;
        public int WaitHint;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct StartupInfo
    {
        public int Size;
        public string? Reserved;
        public string? Desktop;
        public string? Title;
        public int X;
        public int Y;
        public int XSize;
        public int YSize;
        public int XCountChars;
        public int YCountChars;
        public int FillAttribute;
        public int Flags;
        public short ShowWindow;
        public short Reserved2;
        public IntPtr Reserved2Pointer;
        public IntPtr StandardInput;
        public IntPtr StandardOutput;
        public IntPtr StandardError;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct ProcessInformation
    {
        public IntPtr Process;
        public IntPtr Thread;
        public int ProcessId;
        public int ThreadId;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct NativeInput
    {
        public uint Type;
        public InputUnion Union;
    }

    [StructLayout(LayoutKind.Explicit)]
    private struct InputUnion
    {
        [FieldOffset(0)] public KeyboardInput Keyboard;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct KeyboardInput
    {
        public ushort VirtualKey;
        public ushort ScanCode;
        public uint Flags;
        public uint Time;
        public UIntPtr ExtraInfo;
    }

    private sealed class RelayEnvelope
    {
        public long Timestamp { get; set; }
        public string Nonce { get; set; } = "";
        public string Payload { get; set; } = "";
        public string Signature { get; set; } = "";
    }

    private sealed class InputCommand
    {
        public string Type { get; set; } = "";
        public string? Text { get; set; }
        public int KeyCode { get; set; }
        public bool Down { get; set; }
    }

    private delegate void ServiceMainDelegate(int argumentCount, IntPtr arguments);
    private delegate int ServiceHandlerDelegate(int control, int eventType, IntPtr eventData, IntPtr context);

    [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    private static extern bool StartServiceCtrlDispatcher(
        [In] ServiceTableEntry[] serviceTable);

    [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    private static extern IntPtr RegisterServiceCtrlHandlerEx(
        string serviceName, ServiceHandlerDelegate handler, IntPtr context);

    [DllImport("advapi32.dll", SetLastError = true)]
    private static extern bool SetServiceStatus(IntPtr statusHandle, ref ServiceStatus status);

    [DllImport("kernel32.dll")]
    private static extern uint WTSGetActiveConsoleSessionId();

    [DllImport("kernel32.dll")]
    private static extern IntPtr GetCurrentProcess();

    [DllImport("advapi32.dll", SetLastError = true)]
    private static extern bool OpenProcessToken(
        IntPtr processHandle, uint desiredAccess, out IntPtr tokenHandle);

    [DllImport("advapi32.dll", SetLastError = true)]
    private static extern bool DuplicateTokenEx(
        IntPtr existingToken,
        uint desiredAccess,
        IntPtr tokenAttributes,
        int impersonationLevel,
        int tokenType,
        out IntPtr newToken);

    [DllImport("advapi32.dll", SetLastError = true)]
    private static extern bool SetTokenInformation(
        IntPtr tokenHandle, int tokenInformationClass, IntPtr tokenInformation, int tokenInformationLength);

    [DllImport("wtsapi32.dll", SetLastError = true)]
    private static extern bool WTSQueryUserToken(uint sessionId, out IntPtr token);

    [DllImport("userenv.dll", SetLastError = true)]
    private static extern bool CreateEnvironmentBlock(out IntPtr environment, IntPtr token, bool inherit);

    [DllImport("userenv.dll", SetLastError = true)]
    private static extern bool DestroyEnvironmentBlock(IntPtr environment);

    [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    private static extern bool CreateProcessAsUser(
        IntPtr token,
        string? applicationName,
        StringBuilder commandLine,
        IntPtr processAttributes,
        IntPtr threadAttributes,
        bool inheritHandles,
        uint creationFlags,
        IntPtr environment,
        string currentDirectory,
        ref StartupInfo startupInfo,
        out ProcessInformation processInformation);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool CloseHandle(IntPtr handle);

    [DllImport("kernel32.dll")]
    private static extern uint WaitForSingleObject(IntPtr handle, uint milliseconds);

    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(IntPtr window, out uint processId);

    [DllImport("sas.dll")]
    private static extern void SendSAS(
        [MarshalAs(UnmanagedType.Bool)] bool asUser);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern uint SendInput(
        uint inputCount, [In] NativeInput[] inputs, int inputSize);
}
