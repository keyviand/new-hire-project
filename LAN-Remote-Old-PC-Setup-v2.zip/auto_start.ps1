$ErrorActionPreference = 'Stop'
$viewerPortInUse = Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction SilentlyContinue
$adminPortInUse = Get-NetTCPConnection -LocalPort 8767 -State Listen -ErrorAction SilentlyContinue
if ($viewerPortInUse -and $adminPortInUse) {
    exit 0
}
if ($viewerPortInUse -or $adminPortInUse) {
    throw 'LAN Remote is only partially running. Ports 8765 and 8767 must start together.'
}

$stablePython = 'C:\Users\keyvi\AppData\Local\Programs\Python\Python312\python.exe'
$bundledPython = 'C:\Users\keyvi\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$stablePythonReady = $false
if (Test-Path -LiteralPath $stablePython) {
    & $stablePython -c 'import PIL' 2>$null
    $stablePythonReady = $LASTEXITCODE -eq 0
}
if ($stablePythonReady) {
    $python = $stablePython
} elseif (Test-Path -LiteralPath $bundledPython) {
    $python = $bundledPython
} else {
    $pythonCommand = Get-Command python.exe -ErrorAction SilentlyContinue
    if (-not $pythonCommand) {
        throw 'Python is not available. Reinstall Python or update auto_start.ps1.'
    }
    $python = $pythonCommand.Source
}

$logPath = Join-Path $PSScriptRoot 'server.autostart.log'
$previousLogPath = Join-Path $PSScriptRoot 'server.autostart.previous.log'
if ((Test-Path -LiteralPath $logPath) -and (Get-Item -LiteralPath $logPath).Length -gt 10MB) {
    Move-Item -LiteralPath $logPath -Destination $previousLogPath -Force
}

& $python -u "$PSScriptRoot\remote_host.py" *>> $logPath
